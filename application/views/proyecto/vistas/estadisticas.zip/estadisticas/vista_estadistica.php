

<div class="row">
    <div class="menumapa">







        <div class="lupacerrar">               

            <img id="btnlupa" src=../assets/images/fondos/lupa.png width=40 height=40></img>
        </div>


        <div class="lupa">
          
      
            <div class="row">
                <div class="col-md-10">
                  
                    <div class="card-box">

                        <h4 class="header-title m-t-0">Menú de estadísticas GespolMaps</h4>

                        <p class="text-muted font-14 m-b-30">

                        </p>

                        <div class="checkbox checkbox-custom m-t-0">
                            <label>
                                <input type="checkbox" value="" checked>
                                <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                                Villas 
                            </label>
                        </div>
                        <div class="checkbox checkbox-custom m-t-0">
                            <label>
                                <input type="checkbox" value="" checked>  
                                <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                             Cuadrante
                            </label>
                        </div>
                          <div class="checkbox checkbox-custom m-t-0">
                            <label>
                                <input type="checkbox" value="" checked>
                                <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                                Infracciones
                            </label>
                        </div>

                       

                    </div>
                </div>


            </div>



        </div>

    </div>

    <div class="map2" id="map">

    </div>    


    <a href="https://waze.com/ul?ll=-33.4684655,-70.7549331&navigate=yes" target="_blank">MAPA1</a>
    <script type="text/javascript">
        start_estadistica();
    </script>

<!--<iframe src="https://embed.waze.com/iframe?zoom=16&lat=-33.468466&lon=-70.754933&ct=livemap" width="600" height="450" allowfullscreen></iframe>-->

